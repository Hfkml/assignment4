import os, json
import argparse
import spacy
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.dates as mdate

import argparse

parser = argparse.ArgumentParser(description='Term plotter')

parser.add_argument('--terms', type=str, nargs='+',help='a list of up to five terms')
parser.add_argument('--path', default = "home/m17/marufa/p2/us_presidential_speeches/" , type= str)
parser.add_argument('--title', type=str)
parser.add_argument('--output', type=str)

args= parser.parse_args()

terms = args.terms
path = args.path
title = args.title
output = args.output

#create output plot in a specified name

filename = []
for term in terms:
    if " " in term:
        term = "_".join(term.split())
    filename.append(term)
filename = "_".joion(filename)

# If output filename is not given 

if output in None:
    output = file_name+".png"
else:
    output = output+".png"
    
# Keep all the terms and ngrams in a list
ngram = list()
sent = list()

for term in terms:
    ngram.append (len(term.split()))
    sent.append( term.lower())

# upload the input files from the specified directory
speech_dir = "home/m17/marufa/p2/us_presidential_speeches/"
files = os.listdir(speech_dir)

texts = []
dates = []
for file in files:
  with open(speech_dir+file, "r") as infile:
        speech = json.load(infile)
        texts.append(speech['Speech'])
        dates.append(speech['Date'])

# calculate Tf idf score of the whole speech texts and get the ngrams  

speech_texts = texts
frequency_matrix = np.zeros(len(sent), len(speech_texts))
Tfidf_score = TfidfVectorizer(stop_words='english', ngram_range=(1,3))

Y = Tfidf_score.fit_transform(speech_texts)
name_list = vectorizer.get_feature_names()

for i in range(len(sent)):
    if sent[i] in name_list:
        index = name_list.index(sent[i])
        for j in range(Y.shape[0]):
            frequency_matrix[i, j] = X[j, index]
    else:
        assert sent[i] in name_list,"The word: {} doesn't exists in the corpus.".format(sent[i])
        

 # Style of the plot
sns.set(style="whitegrid")

#  extract the frequency of terms and concatenate them into an vector.
score = frequency_matrix[0, :]
for i in range(1, frequency_matrix.shape[0]):
    score = np.concatenate((score, frequency_matrix[i, :]), axis=None)

all_dates = np.array(dates*len(terms))
all_dates = pd.to_datetime(all_date)

term = []
for i in sent:
    dummy = [i]
    dummy *= frequency_matrix.shape[1]
    term.extend(dummy)
term = np.array(term)

# prepare date, score and term for pandas

data = dict()
data ['Date'] = all_date
data ['Score'] = score
data ['Term'] = term

df = pd.DataFrame(data)

# Draw plot, set title & save the figure in the same directory as the program.
ax = sns.relplot(x='Date', y='Score',
                 data=df, hue='Term', kind='line', aspect=2)
plt.title(title)
ax.savefig(output)
