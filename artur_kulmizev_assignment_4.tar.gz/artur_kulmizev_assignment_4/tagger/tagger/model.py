from sklearn.svm import LinearSVC
from .pre_process import token_to_features
from tagger import pre_process
import numpy as np
import pickle
import spacy
import time
from sklearn.metrics import classification_report as c_r
from sklearn.linear_model import SGDClassifier

nlp = spacy.load("en_core_web_sm")

def fit_and_report(X, Y, cross_val = True, n_folds=5):

    svm = LinearSVC()

    if cross_val:
        from sklearn.model_selection import cross_val_score
        print(f"Doing {n_folds}-fold cross-validation.")
        scores = cross_val_score(svm, X, Y, cv=n_folds)
        print(f"{n_folds}-fold cross-validation results over training set:\n")
        print("Fold\tScore".expandtabs(15))
        for i in range(n_folds):
            print(f"{i+1}\t{scores[i]:.3f}".expandtabs(15))
        print(f"Average\t{np.mean(scores):.3f}".expandtabs(15))

    print("Fitting model.")
    start_time = time.time()
    svm.fit(X, Y)
    end_time = time.time()
    print(f"Took {int(end_time - start_time)} seconds.")

    return svm

def save_model(model_and_vec, output_file):
    print(f"Saving model to {output_file}.")
    with open(output_file, "wb") as outfile:
        pickle.dump(model_and_vec, outfile)

def load_model(output_file):
    print(f"Loading model from {output_file}.")
    with open(output_file, "rb") as infile:
        model, vec = pickle.load(infile)

    return model, vec

def tag_sentence(sentence, model, vec):
    doc = nlp(sentence)
    tokenized_sent = [token.text for token in doc]
    featurized_sent = []
    for i, token in enumerate(tokenized_sent):
        featurized_sent.append(token_to_features(tokenized_sent, i))

    featurized_sent = vec.transform(featurized_sent)
    labels = model.predict(featurized_sent)
    tagged_sent = list(zip(tokenized_sent, labels))

    return tagged_sent

def tag_file(txt, model, vec, file_n):
    tagged_txt = []
    doc = nlp(txt)
    for sentence in doc.sents:
        tokenized_sent = [token.text for token in sentence]
        featurized_sent = []
        for j, token in enumerate(tokenized_sent):
            featurized_sent.append(token_to_features(tokenized_sent, j))
        featurized_sent = vec.transform(featurized_sent)
        tags = model.predict(featurized_sent)
        tagged_sent = list(zip(tokenized_sent, tags))
        tagged_txt.append(tagged_sent)
        
        fn = file_n + '.tag'
        with open(fn, "wt") as outfile:
            for tagged_sent in tagged_txt:
                for token in tagged_sent:
                    outfile.write(f"{token[0]}\t{token[1]}\n".expandtabs(15))
                outfile.write('\n')
            outfile.write('\n')

def print_tagged_sent(tagged_sent):
    for token in tagged_sent:
        print(f"{token[0]}\t{token[1]}".expandtabs(15))

def evalu(X, Y, svm, vec):
    vectorize = vec.transform(X)
    labels = svm.predict(vectorize)
    return c_r(Y, labels)

def SGDclass(X, Y, cross_val=True, n_folds=5):
    sgd = SGDClassifier()
    if cross_val:
        from sklearn.model_selection import cross_val_score
        print(f"Doing {n_folds}-fold cross-validation")
        scores = cross_val_score(sgd, X, Y, cv=n_folds)
        print(f"{n_folds}-fold cross-validation results over training set:\n")
        print("Fold\tScore".expandtabs(15))
        for i in range(n_folds):
            print(f"{i+1}\t{scores[i]:.3f}".expandtabs(15))
        print(f"Average\t{np.mean(scores):.3f}".expandtabs(15))
    print("Fitting model.")
    start_time = time.time()
    sgd.fit(X, Y)
    end_time = time.time()
    print(f"Took {int(end_time - start_time)} seconds.")

    return sgd
        
   
    
    
    
    
    

