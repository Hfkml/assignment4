twitter_query.py contains a function retrieve_tweets, which takes two arguments, a twitter username and a number, and prints the number of most recent tweets by this user.
 
The number is an optional argument, and, if left blank retrieves the most recent tweet.

No distinction is made between tweets, replies, or retweets, and no special encoding is used for non-ASCII characters.