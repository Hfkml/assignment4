from bs4 import BeautifulSoup
import urllib
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import urlopen
import argparse

def wiki_query(name):
  if ' ' in name:
    name = name.replace(' ', '_')
  name = urllib.parse.quote(name, safe='/', encoding='utf8', errors=None)
  site_string = f"https://en.wikipedia.org/wiki/{name}"
  try:
    soup = BeautifulSoup(urlopen(site_string), "html.parser")
    for paragraph in soup.find_all("p"):
      print(paragraph.get_text())
  except HTTPError:
    print(f"There is no wikipedia page named {name}")

def run(args):
  wiki_query(args.subject)

if __name__ == '__main__':

  PARSER = argparse.ArgumentParser(description=
                                   """
                                   Retrieves the wikipedia page
                                   of the utf8 encoded subject.
                                   """)
  PARSER.add_argument('--subject', metavar='S', type=str, help=
                     """
                     The page you want to look up.
                     """)
  ARGS = PARSER.parse_args()
  run(ARGS)
