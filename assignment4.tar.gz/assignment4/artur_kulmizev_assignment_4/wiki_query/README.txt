wiki_query.py has a function wiki_query, which takes one argument and retrieves the wikipedia page of what is written in this argument. 

It uses utf8 encoding in order to handle non ASCII characters.

