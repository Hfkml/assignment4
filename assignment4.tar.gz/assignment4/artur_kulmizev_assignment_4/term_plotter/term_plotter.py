import os, json
import argparse
import spacy
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
from sklearn.feature_extraction.text import TfidfVectorizer
import argparse
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()


parser = argparse.ArgumentParser(description='Term plotter')

#Create current directory
current_dir = os.path.abspath('.').replace('\\', '/') + \
            '/us_presidential_speeches/'
#Add parser and four parameters.
parser.add_argument('--terms', type=str, nargs='*',help='a list of up to five terms')
parser.add_argument('--path', nargs = '?', const= current_dir, default= current_dir, type= str)
parser.add_argument('--title', type=str)
parser.add_argument('--output', type=str)

args= parser.parse_args()

#pass the parameters , term, path ,title, output
terms = args.terms
path = args.path
title = args.title
output = args.output

# Send error if the path the user type in does not exist.
assert os.path.exists(path), "The directory does not exist."

#create output plot in a specified name
filename = []
for term in terms:
    if " " in term:
        term = "_".join(term.split())
    filename.append(term)
filename = "_".join(filename)

# If output filename is not given 
if output == None:
    output = filename+".png"
else:
    output = output+".png"
    
# lowercase all the terms and keep then in a list
ngram = list()
sent = list()

for term in terms:
    ngram.append (len(term.split()))
    sent.append( term.lower())

# upload the input files from the specified directory
speech_dir = path
files = os.listdir(speech_dir)

# Save dates and the speech texts into two lists
texts = []
dates = []
number_files = 0
for file in files:
  with open(speech_dir+file, "r") as infile:
        speech = json.load(infile)
        texts.append(speech['Speech'])
        dates.append(speech['Date'])
        number_files += 1
        
df_date = pd.DataFrame({'Date': dates})
df_date['Date'] = pd.to_datetime(df_date.Date) 

# calculate Tf idf score of the whole speech texts and get the ngrams  
speech_texts = texts
Tfidf_score = TfidfVectorizer(stop_words='english', ngram_range=(1,3))
Y = Tfidf_score.fit_transform(speech_texts)

# Raise error if the word is not in the corpus
name_list = Tfidf_score.get_feature_names()
for i in range(len(sent)):
    assert sent[i] in name_list, \
            "The word: {} you write does not exist.".format(sent[i])


#collect all scores in pd dataframe
df_all_scores = pd.DataFrame(Y.toarray(), columns=Tfidf_score.get_feature_names())

#  extract the frequency of terms,score and concatenate them into an vector.
dataframes = []
for term in terms:
    df_term = pd.df_term = pd.DataFrame({'term': [term] * number_files})
    df_score = pd.DataFrame({'Score': df_all_scores[term]})
    table = pd.concat([df_date, df_score, df_term], axis=1, sort=False)
    dataframes.append(table)
    result = pd.concat(dataframes)

 # Style of the plot
sns.set(style="whitegrid")

# Draw plot, set title & save the figure in the same directory as the program.
ax = sns.relplot(x='Date', y='Score',
                 data=result, hue='term', kind='line', aspect=2)
plt.title(title)
ax.savefig(output)
