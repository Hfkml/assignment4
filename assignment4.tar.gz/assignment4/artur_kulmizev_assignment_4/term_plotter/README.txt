term_plotter.py is a python script that takes a raw text us_presidential_speeches as corpus and gives output of an image. 

Configuration
--------------

1. Install os ,  json , argparse, spacy, numpy, panda, seaborn and matplotlib
2. Takes us_presidential_speeches as corpus and keep speeches in one list and dates in another lists.
3. It can takes upto four arguments: 
	firstly, It can take a list up to five terms in quotation, seperated by white space with English stopwords assumed to be filtered out.
	Secondly, an optional path is given as default if not provided.
	Thirdly, an optional title, if not given the program output without title.
	Fourthly, output will be saved in an image file named according to the term provided seperated by an underscore token. 

4. After the terms given the program then calculate Tf idf score of the whole texts and get the ngams.
5. Then extract the frequency of terms and concatenate them into an vector.
6. Prepare date, score and term for pandas 
7. Draw plot, set title & save the figure in the same directory as the program.



