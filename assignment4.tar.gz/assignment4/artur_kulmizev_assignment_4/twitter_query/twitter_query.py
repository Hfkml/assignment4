import tweepy
import argparse

auth = tweepy.OAuthHandler('enX88ZwYrs6j06zyX1fQvIDmU', 'PLYNUXdqfU39NSkDTAC0qCnjeiXJM3qnlfP7YzcbyWX8O1EhvU')
auth.set_access_token('1229723138461749248-xifzp6qXZqhXVixQ4a9HpNHteFGtXu', 'ADtZTGfEqQCRX9dTWn42xWaiINktBseLTi4kvfPwnanUi')

api = tweepy.API(auth)

def retrieve_tweets(user, number=1):
  variable = number
  if variable == None:
    number = 1 
  try:
    for i, tweet in enumerate(api.user_timeline(user)):
        print(tweet.created_at, tweet.text)
        if i == number-1:
          break
  except IndexError:
    print('This user does not have', number, 'tweets')

def run(args):
  retrieve_tweets(args.user, args.number)

if __name__ == '__main__':

  PARSER = argparse.ArgumentParser(description=
                                   """
                                   This function retrieves tweets by a public user.
                                   """)
  PARSER.add_argument('--user', metavar='U', type=str, help=
                      """
                      Specifies the username of the twitter user
                      """)
  PARSER.add_argument('--number', metavar='N', nargs='?', const=1, type=int, help=
                      """
                      Specifies the number of tweets to be retrieved.
                      """)
  ARGS = PARSER.parse_args()

  run(ARGS)
